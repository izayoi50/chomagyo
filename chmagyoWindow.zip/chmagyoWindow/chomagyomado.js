/*


ここは見ちゃだめ！
(*ﾟ▽ﾟ* っ)З



ここは見ちゃだめ！
(*ﾟ▽ﾟ* っ)З



ここは見ちゃだめ ちょまぎょまど〜♪
(*ﾟ▽ﾟ* っ)З




ここは見ちゃだめ！
(*ﾟ▽ﾟ* っ)З



ここは見ちゃだめ！
(*ﾟ▽ﾟ* っ)З



ここは見ちゃだめ ちょまぎょまど〜♪
(*ﾟ▽ﾟ* っ)З





見たら中身がわかっちゃう
(*ﾟ▽ﾟ* っ)З



楽しみ半減 ちょまぎょまど〜♪
(*ﾟ▽ﾟ* っ)З



まだ見てる？
(*ﾟ▽ﾟ* っ)З



まだ見てる？
(*ﾟ▽ﾟ* っ)З


まだまだ見てるの ちょまぎょまど〜♪
(*ﾟ▽ﾟ* っ)З










(*ﾟ▽ﾟ* っ)З










(*ﾟ▽ﾟ* っ)З









ぶんしん！
(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З(*ﾟ▽ﾟ* っ)З























まだ見てる！
(*ﾟ▽ﾟ* っ)З



じゃあせめてものテイコー
(*ﾟ▽ﾟ* っ)З










みにまむ！
(*ﾟ▽ﾟ* っ)З







*/

let chomaCount = 0;
let bgcolor = 1;
window.addEventListener('load', chomaInit);
window.addEventListener('resize', resizeWindow);


let timer = null;
let chomaWin = document.getElementsByTagName("body");
let chomagyo = document.getElementById("chomagyo");
let chomaTxt = document.getElementById("chomaText");
let chomaBody = document.getElementById("chomaBody");



let chomaPos = null;
let chomaPosX = 0;
let chomaPosY = 0;

let rnd = 0;
let rndT = 0;
let sp = 0;
let spBody = document.getElementById("SP");
let sp2Body = document.getElementById("SP2");
let tmp;

function chomaInit() {
  //console.log("chomaInit");
  chomaTxt.innerHTML = "";
  // 要素の位置座標を取得
  // 
  //window内真ん中
  chomaCenter();
  chomaPos = chomagyo.getBoundingClientRect();
  chomaPosX = chomaPos.left;
  chomaPosY = chomaPos.top;

	
	//console.log(chomaPosX);
	
	//console.log(chomaPosY);
	
	
  let dateCheck = new Date();
  let month = dateCheck.getMonth() + 1;
  let date = dateCheck.getDate();
  //if(month == 11 && date == 27){//お誕生日の最初だけメッセージ
	chomaBody.innerHTML = "(*ﾟ▽ﾟ*  っ)З"; //本体リセット
  if (month == 11 && date == 27) { //お誕生日の最初だけメッセージ
    chomaTxt.innerHTML = "Happy Birthday♪";

    
    chomaTxt.style.color = "PINK";
    chomaTxt.style.fontSize = "1.3rem";
  }else{chomaTxt.innerHTML="ちょまぎょまど";}


}

function resizeWindow() {
  //console.log("resizeWindow");
  chomaInit();
}

function chomaCenter() {
  //console.log("chomaCenter");
  //window内真ん中
  chomagyo.style.top = "40%";
  //chomagyo.style.left = "45%";
  leftPos = window.innerWidth / 2 - 120;
//  //console.log(window.innerWidth);
//  //console.log(leftPos);
  chomagyo.style.left = leftPos + "px";
}


let Func = function () {
  chomaCount++;
  if (chomaCount > 20) { //動作方向は20回ごとで決定
    rnd = Math.floor(Math.random() * 4);
    //rnd = 3;
    rndT = Math.floor(Math.random() * 1000); //テキストも20回ごとで変更（ランダム1000で判定）
	  if (rndT <= 50) {//20分の１でここ
		  rndT = Math.floor(rndT / 5)
		} //出やすいテキストは1/20で出現


    chomaTxt.innerHTML = ""; //文字列リセット
    chomaTxt.style.color = "#fff"; //文字色リセット
    chomaTxt.style.fontSize = "0.8rem"; //文字サイズリセット
    chomaBody.innerHTML = "(*ﾟ▽ﾟ*  っ)З"; //本体リセット

    //範囲チェック
    if (chomaPosX > (window.innerWidth - 40) && rnd == 0) rnd = 1;
    if (chomaPosX < 40 && rnd == 1) rnd = 0;
    if (chomaPosY > (window.innerHeight - 100) && rnd == 2) rnd = 3;
    if (chomaPosY < 40 && rnd == 3) rnd = 2;

   // //console.log(["右", "左", "下", "上"][rnd]);
	  sp++; 
    chomaCount=0;
////console.log(chomaCount);
//console.log(sp);
	  
	  switch(sp){
		  case 1:spBody.style.opacity = "0";
			 break;
		case 290:console.log("そろそろお友達が来る予感♪　(*ﾟ▽ﾟ* っ)З");
		  case 300:
		  case 900:
			  spBody.style.opacity = "1";
			 break;
		case 490:console.log("そろそろお友達が来る予感♪　(*ﾟ▽ﾟ* っ)З");
			 break;
			  
		  case 500:sp2Body.style.opacity = "1";sp2Body.style.left = "110%";sp2Body.classList.add("anim");
			 break;
		case 590:console.log("そろそろお友達が来る予感♪　(*ﾟ▽ﾟ* っ)З");
		  case 600:spBody.style.opacity = "0";
			 break;
		  case 1000:sp2Body.style.opacity = "0";sp2Body.style.left = "110%";sp2Body.classList.remove("anim");
			  bgcolor = bgcolor * -1;
			  sp = 0;
			 break;
			 }
	  
	// chomaWin.style.backgroundColor =  "rgb(143,209,219)";
	  style="background-color: rgb(177, 242, 185);";
	  tmp = parseInt(sp/30);
	//  colortmp = "rgb(" + (143-tmp*bgcolor) + "," + (208-tmp*bgcolor) + ","  + (219+tmp*bgcolor) + ")";
		  colortmp = "rgb(143,208,"  + (219+tmp*bgcolor) + ")";
	  //console.log (colortmp);
	  
	   chomaWin[0].style.backgroundColor =  colortmp;
//console.log (rndT);
    switch (rndT) {
      case 0:
        chomaTxt.innerHTML = "ちょまぎょ♪";
        break;
      case 1:
        chomaTxt.innerHTML = "ぽぽー";
        break;
      case 2:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1464253113003495432' target='_brank'>ちょまぎょのうた！</a>";
        break;
      case 3:
        chomaTxt.innerHTML = "じろ～";
        break;
      case 4:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1394991129624518658' target='_brank'>にこー！</a>";
        break;
      case 5:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1400755927083413508' target='_brank'>あおぞら！</a>";
        break;
      case 6:
        chomaTxt.innerHTML = "<a href='https://www.matsuyafoods.co.jp' target='_brank'>まつや！</a>";
        break;
      case 7:
        chomaTxt.innerHTML = "ぶるぶる";
        chomaBody.innerHTML = "(((((*ﾟ▽ﾟ*  っ)З)))))";
        break;
      case 8:
        chomaTxt.innerHTML = "ぶーん！";
        chomaBody.innerHTML = "(*ﾟ▽ﾟ* っ)З ===3 ";
        break;
      case 9:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/731741430264139777' target='_brank'>とちおとめ！</a>";
        break;
      case 10:
        chomaTxt.innerHTML = "もぐもぐ！";
        break;
			
	case 101:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1242564424654708736' target='_brank'>ちょまぎょの可愛い bot!</a>";
        break;
	case 102:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1362601287926259713' target='_brank'>Teams で動くちょまぎょ！</a>";
        break;
	case 103:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1407595990467551239' target='_brank'>ちょまど！</a>";
        break;
	case 104:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1181149246864519168' target='_brank'>ちょまぎょは、アザラシ♪</a>";
        break;
	case 105:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1312125678762913793' target='_brank'>手に追従する ちょまぎょ♪</a>";
        break;
	case 106:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1230047509336035328' target='_brank'>空間に『ちょまぎょ』♪</a>";
        break;
	case 107:
			chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1288445774032809984' target='_brank'>3Dモデル♪</a>";
			break;
	case 108:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1239807011795001345' target='_brank'>いくちょんが描いてくれた♪</a>";
			break;
	case 109:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1454694840113897480' target='_brank'>C#でちょまぎょAPI♪</a>";
			break;
	case 110:
        chomaTxt.innerHTML = "<a href='https://twitter.com/chomado/status/1372444988504633346' target='_brank'>on ダッフィー♪</a>";
			break;
			
      default:
        chomaTxt.innerHTML = "";
    }

//console.log(chomaTxt.innerHTML + chomaBody.innerHTML) ;
    /*
    Babylon.js はいいぞ
    https://zenn.dev/chomado/books/babylonjs-tutorial-ja
    */

  }
 // sp = Math.floor(Math.random() * 4);
  //sp = sp * 10;
  ////console.log(chomaCount+":"+sp+":"+rnd);
  switch (rnd) {
    case 0:
      chomaPosX = chomaPosX + 1;
      chomagyo.style.left = chomaPosX + "px";
      //chomagyo.innerHTML = "0";
      break;
    case 1:
      chomaPosX = chomaPosX - 1;
      chomagyo.style.left = chomaPosX + "px";
      //chomagyo.innerHTML = "1";
      break;
    case 2:
    //  //console.log("Y:" + chomaPosY);
      chomaPosY = chomaPosY + 1;
      chomagyo.style.top = chomaPosY + "px";
      //chomagyo.innerHTML = "2";
  //    //console.log("Y:" + chomaPosY);
      ////console.log("SP:" + sp);
      break;
    case 3:
      chomaPosY = chomaPosY - 1;
      chomagyo.style.top = chomaPosY + "px";
      break;
  };
  // //console.log("rndT" + rndT);
  //chomagyo.innerHTML = "(*ﾟ▽ﾟ*　　　　　　っ)З びろーん";

  ////console.log("chomaPosY:"+chomaPosY+"・chomaPosX:"+chomaPosX);
};
let spAction = function () {
  if (!timer) timer = setInterval(spFunc, 300);
};
let chomAction = function () {
  if (!timer) timer = setInterval(Func, 300);
};

chomAction();
console.log("ｷｻﾏ!  ﾐﾃｲﾙﾅ!! (*ﾟ▽ﾟ* っ)З");
//alert(chomAction);
